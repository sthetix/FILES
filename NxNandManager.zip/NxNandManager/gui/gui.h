#pragma once
#ifndef __gui_h__
#define __gui_h__

#define ENABLE_GUI  1 // Comment this line to build CLI version only

#endif
